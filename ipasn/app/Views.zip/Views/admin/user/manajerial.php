<script charset="utf-8" src="Bangkom%20-%20LAN%20RI_files/e6e8f262e15fcb82c4f6.js"></script><script charset="utf-8" src="Bangkom%20-%20LAN%20RI_files/7328ae0525109a4d3354.js"></script><link rel="stylesheet" type="text/css" href="Bangkom%20-%20LAN%20RI_files/c600111a7bcc8a1522a8.css"><script charset="utf-8" src="Bangkom%20-%20LAN%20RI_files/23d389179b4b76b67569.js"></script><meta name="viewport" content="width=device-width, initial-scale=1" data-n-head="true"><style id="vuetify-theme-stylesheet" type="text/css" data-n-head="true">a { color: #8c0723; }
.primary {
  background-color: #8c0723 !important;
  border-color: #8c0723 !important;
}
.primary--text {
  color: #8c0723 !important;
  caret-color: #8c0723 !important;
}
.primary.lighten-5 {
  background-color: #ff9b9a !important;
  border-color: #ff9b9a !important;
}
.primary--text.text--lighten-5 {
  color: #ff9b9a !important;
  caret-color: #ff9b9a !important;
}
.primary.lighten-4 {
  background-color: #ff7f80 !important;
  border-color: #ff7f80 !important;
}
.primary--text.text--lighten-4 {
  color: #ff7f80 !important;
  caret-color: #ff7f80 !important;
}
.primary.lighten-3 {
  background-color: #e76467 !important;
  border-color: #e76467 !important;
}
.primary--text.text--lighten-3 {
  color: #e76467 !important;
  caret-color: #e76467 !important;
}
.primary.lighten-2 {
  background-color: #c8494f !important;
  border-color: #c8494f !important;
}
.primary--text.text--lighten-2 {
  color: #c8494f !important;
  caret-color: #c8494f !important;
}
.primary.lighten-1 {
  background-color: #aa2d38 !important;
  border-color: #aa2d38 !important;
}
.primary--text.text--lighten-1 {
  color: #aa2d38 !important;
  caret-color: #aa2d38 !important;
}
.primary.darken-1 {
  background-color: #6f000e !important;
  border-color: #6f000e !important;
}
.primary--text.text--darken-1 {
  color: #6f000e !important;
  caret-color: #6f000e !important;
}
.primary.darken-2 {
  background-color: #530000 !important;
  border-color: #530000 !important;
}
.primary--text.text--darken-2 {
  color: #530000 !important;
  caret-color: #530000 !important;
}
.primary.darken-3 {
  background-color: #3e0000 !important;
  border-color: #3e0000 !important;
}
.primary--text.text--darken-3 {
  color: #3e0000 !important;
  caret-color: #3e0000 !important;
}
.primary.darken-4 {
  background-color: #360000 !important;
  border-color: #360000 !important;
}
.primary--text.text--darken-4 {
  color: #360000 !important;
  caret-color: #360000 !important;
}
.secondary {
  background-color: #a6062a !important;
  border-color: #a6062a !important;
}
.secondary--text {
  color: #a6062a !important;
  caret-color: #a6062a !important;
}
.secondary.lighten-5 {
  background-color: #ffa3a3 !important;
  border-color: #ffa3a3 !important;
}
.secondary--text.text--lighten-5 {
  color: #ffa3a3 !important;
  caret-color: #ffa3a3 !important;
}
.secondary.lighten-4 {
  background-color: #ff8789 !important;
  border-color: #ff8789 !important;
}
.secondary--text.text--lighten-4 {
  color: #ff8789 !important;
  caret-color: #ff8789 !important;
}
.secondary.lighten-3 {
  background-color: #ff6b70 !important;
  border-color: #ff6b70 !important;
}
.secondary--text.text--lighten-3 {
  color: #ff6b70 !important;
  caret-color: #ff6b70 !important;
}
.secondary.lighten-2 {
  background-color: #e44f57 !important;
  border-color: #e44f57 !important;
}
.secondary--text.text--lighten-2 {
  color: #e44f57 !important;
  caret-color: #e44f57 !important;
}
.secondary.lighten-1 {
  background-color: #c53140 !important;
  border-color: #c53140 !important;
}
.secondary--text.text--lighten-1 {
  color: #c53140 !important;
  caret-color: #c53140 !important;
}
.secondary.darken-1 {
  background-color: #870016 !important;
  border-color: #870016 !important;
}
.secondary--text.text--darken-1 {
  color: #870016 !important;
  caret-color: #870016 !important;
}
.secondary.darken-2 {
  background-color: #6a0000 !important;
  border-color: #6a0000 !important;
}
.secondary--text.text--darken-2 {
  color: #6a0000 !important;
  caret-color: #6a0000 !important;
}
.secondary.darken-3 {
  background-color: #4f0000 !important;
  border-color: #4f0000 !important;
}
.secondary--text.text--darken-3 {
  color: #4f0000 !important;
  caret-color: #4f0000 !important;
}
.secondary.darken-4 {
  background-color: #3f0000 !important;
  border-color: #3f0000 !important;
}
.secondary--text.text--darken-4 {
  color: #3f0000 !important;
  caret-color: #3f0000 !important;
}
.accent {
  background-color: #9c27b0 !important;
  border-color: #9c27b0 !important;
}
.accent--text {
  color: #9c27b0 !important;
  caret-color: #9c27b0 !important;
}
.accent.lighten-5 {
  background-color: #ffb6ff !important;
  border-color: #ffb6ff !important;
}
.accent--text.text--lighten-5 {
  color: #ffb6ff !important;
  caret-color: #ffb6ff !important;
}
.accent.lighten-4 {
  background-color: #ff9aff !important;
  border-color: #ff9aff !important;
}
.accent--text.text--lighten-4 {
  color: #ff9aff !important;
  caret-color: #ff9aff !important;
}
.accent.lighten-3 {
  background-color: #f47eff !important;
  border-color: #f47eff !important;
}
.accent--text.text--lighten-3 {
  color: #f47eff !important;
  caret-color: #f47eff !important;
}
.accent.lighten-2 {
  background-color: #d662e8 !important;
  border-color: #d662e8 !important;
}
.accent--text.text--lighten-2 {
  color: #d662e8 !important;
  caret-color: #d662e8 !important;
}
.accent.lighten-1 {
  background-color: #b946cc !important;
  border-color: #b946cc !important;
}
.accent--text.text--lighten-1 {
  color: #b946cc !important;
  caret-color: #b946cc !important;
}
.accent.darken-1 {
  background-color: #800095 !important;
  border-color: #800095 !important;
}
.accent--text.text--darken-1 {
  color: #800095 !important;
  caret-color: #800095 !important;
}
.accent.darken-2 {
  background-color: #64007b !important;
  border-color: #64007b !important;
}
.accent--text.text--darken-2 {
  color: #64007b !important;
  caret-color: #64007b !important;
}
.accent.darken-3 {
  background-color: #490061 !important;
  border-color: #490061 !important;
}
.accent--text.text--darken-3 {
  color: #490061 !important;
  caret-color: #490061 !important;
}
.accent.darken-4 {
  background-color: #300049 !important;
  border-color: #300049 !important;
}
.accent--text.text--darken-4 {
  color: #300049 !important;
  caret-color: #300049 !important;
}
.error {
  background-color: #ef5350 !important;
  border-color: #ef5350 !important;
}
.error--text {
  color: #ef5350 !important;
  caret-color: #ef5350 !important;
}
.error.lighten-5 {
  background-color: #ffe2d2 !important;
  border-color: #ffe2d2 !important;
}
.error--text.text--lighten-5 {
  color: #ffe2d2 !important;
  caret-color: #ffe2d2 !important;
}
.error.lighten-4 {
  background-color: #ffc5b7 !important;
  border-color: #ffc5b7 !important;
}
.error--text.text--lighten-4 {
  color: #ffc5b7 !important;
  caret-color: #ffc5b7 !important;
}
.error.lighten-3 {
  background-color: #ffa89c !important;
  border-color: #ffa89c !important;
}
.error--text.text--lighten-3 {
  color: #ffa89c !important;
  caret-color: #ffa89c !important;
}
.error.lighten-2 {
  background-color: #ff8c82 !important;
  border-color: #ff8c82 !important;
}
.error--text.text--lighten-2 {
  color: #ff8c82 !important;
  caret-color: #ff8c82 !important;
}
.error.lighten-1 {
  background-color: #ff6f68 !important;
  border-color: #ff6f68 !important;
}
.error--text.text--lighten-1 {
  color: #ff6f68 !important;
  caret-color: #ff6f68 !important;
}
.error.darken-1 {
  background-color: #cf3539 !important;
  border-color: #cf3539 !important;
}
.error--text.text--darken-1 {
  color: #cf3539 !important;
  caret-color: #cf3539 !important;
}
.error.darken-2 {
  background-color: #b00d23 !important;
  border-color: #b00d23 !important;
}
.error--text.text--darken-2 {
  color: #b00d23 !important;
  caret-color: #b00d23 !important;
}
.error.darken-3 {
  background-color: #91000e !important;
  border-color: #91000e !important;
}
.error--text.text--darken-3 {
  color: #91000e !important;
  caret-color: #91000e !important;
}
.error.darken-4 {
  background-color: #730000 !important;
  border-color: #730000 !important;
}
.error--text.text--darken-4 {
  color: #730000 !important;
  caret-color: #730000 !important;
}
.info {
  background-color: #26a69a !important;
  border-color: #26a69a !important;
}
.info--text {
  color: #26a69a !important;
  caret-color: #26a69a !important;
}
.info.lighten-5 {
  background-color: #c3ffff !important;
  border-color: #c3ffff !important;
}
.info--text.text--lighten-5 {
  color: #c3ffff !important;
  caret-color: #c3ffff !important;
}
.info.lighten-4 {
  background-color: #a5ffff !important;
  border-color: #a5ffff !important;
}
.info--text.text--lighten-4 {
  color: #a5ffff !important;
  caret-color: #a5ffff !important;
}
.info.lighten-3 {
  background-color: #87fbed !important;
  border-color: #87fbed !important;
}
.info--text.text--lighten-3 {
  color: #87fbed !important;
  caret-color: #87fbed !important;
}
.info.lighten-2 {
  background-color: #6aded0 !important;
  border-color: #6aded0 !important;
}
.info--text.text--lighten-2 {
  color: #6aded0 !important;
  caret-color: #6aded0 !important;
}
.info.lighten-1 {
  background-color: #4bc2b5 !important;
  border-color: #4bc2b5 !important;
}
.info--text.text--lighten-1 {
  color: #4bc2b5 !important;
  caret-color: #4bc2b5 !important;
}
.info.darken-1 {
  background-color: #008b80 !important;
  border-color: #008b80 !important;
}
.info--text.text--darken-1 {
  color: #008b80 !important;
  caret-color: #008b80 !important;
}
.info.darken-2 {
  background-color: #007167 !important;
  border-color: #007167 !important;
}
.info--text.text--darken-2 {
  color: #007167 !important;
  caret-color: #007167 !important;
}
.info.darken-3 {
  background-color: #00584f !important;
  border-color: #00584f !important;
}
.info--text.text--darken-3 {
  color: #00584f !important;
  caret-color: #00584f !important;
}
.info.darken-4 {
  background-color: #004038 !important;
  border-color: #004038 !important;
}
.info--text.text--darken-4 {
  color: #004038 !important;
  caret-color: #004038 !important;
}
.success {
  background-color: #4caf50 !important;
  border-color: #4caf50 !important;
}
.success--text {
  color: #4caf50 !important;
  caret-color: #4caf50 !important;
}
.success.lighten-5 {
  background-color: #dcffd6 !important;
  border-color: #dcffd6 !important;
}
.success--text.text--lighten-5 {
  color: #dcffd6 !important;
  caret-color: #dcffd6 !important;
}
.success.lighten-4 {
  background-color: #beffba !important;
  border-color: #beffba !important;
}
.success--text.text--lighten-4 {
  color: #beffba !important;
  caret-color: #beffba !important;
}
.success.lighten-3 {
  background-color: #a2ff9e !important;
  border-color: #a2ff9e !important;
}
.success--text.text--lighten-3 {
  color: #a2ff9e !important;
  caret-color: #a2ff9e !important;
}
.success.lighten-2 {
  background-color: #85e783 !important;
  border-color: #85e783 !important;
}
.success--text.text--lighten-2 {
  color: #85e783 !important;
  caret-color: #85e783 !important;
}
.success.lighten-1 {
  background-color: #69cb69 !important;
  border-color: #69cb69 !important;
}
.success--text.text--lighten-1 {
  color: #69cb69 !important;
  caret-color: #69cb69 !important;
}
.success.darken-1 {
  background-color: #2d9437 !important;
  border-color: #2d9437 !important;
}
.success--text.text--darken-1 {
  color: #2d9437 !important;
  caret-color: #2d9437 !important;
}
.success.darken-2 {
  background-color: #00791e !important;
  border-color: #00791e !important;
}
.success--text.text--darken-2 {
  color: #00791e !important;
  caret-color: #00791e !important;
}
.success.darken-3 {
  background-color: #006000 !important;
  border-color: #006000 !important;
}
.success--text.text--darken-3 {
  color: #006000 !important;
  caret-color: #006000 !important;
}
.success.darken-4 {
  background-color: #004700 !important;
  border-color: #004700 !important;
}
.success--text.text--darken-4 {
  color: #004700 !important;
  caret-color: #004700 !important;
}
.warning {
  background-color: #ffc107 !important;
  border-color: #ffc107 !important;
}
.warning--text {
  color: #ffc107 !important;
  caret-color: #ffc107 !important;
}
.warning.lighten-5 {
  background-color: #ffffae !important;
  border-color: #ffffae !important;
}
.warning--text.text--lighten-5 {
  color: #ffffae !important;
  caret-color: #ffffae !important;
}
.warning.lighten-4 {
  background-color: #ffff91 !important;
  border-color: #ffff91 !important;
}
.warning--text.text--lighten-4 {
  color: #ffff91 !important;
  caret-color: #ffff91 !important;
}
.warning.lighten-3 {
  background-color: #ffff74 !important;
  border-color: #ffff74 !important;
}
.warning--text.text--lighten-3 {
  color: #ffff74 !important;
  caret-color: #ffff74 !important;
}
.warning.lighten-2 {
  background-color: #fff956 !important;
  border-color: #fff956 !important;
}
.warning--text.text--lighten-2 {
  color: #fff956 !important;
  caret-color: #fff956 !important;
}
.warning.lighten-1 {
  background-color: #ffdd37 !important;
  border-color: #ffdd37 !important;
}
.warning--text.text--lighten-1 {
  color: #ffdd37 !important;
  caret-color: #ffdd37 !important;
}
.warning.darken-1 {
  background-color: #e0a600 !important;
  border-color: #e0a600 !important;
}
.warning--text.text--darken-1 {
  color: #e0a600 !important;
  caret-color: #e0a600 !important;
}
.warning.darken-2 {
  background-color: #c18c00 !important;
  border-color: #c18c00 !important;
}
.warning--text.text--darken-2 {
  color: #c18c00 !important;
  caret-color: #c18c00 !important;
}
.warning.darken-3 {
  background-color: #a27300 !important;
  border-color: #a27300 !important;
}
.warning--text.text--darken-3 {
  color: #a27300 !important;
  caret-color: #a27300 !important;
}
.warning.darken-4 {
  background-color: #855a00 !important;
  border-color: #855a00 !important;
}
.warning--text.text--darken-4 {
  color: #855a00 !important;
  caret-color: #855a00 !important;
}</style></head>
  <body>
   
                    
                    <div data-v-4a02086c="" class="flex xs12"><div data-v-4a02086c="" class="v-tabs" data-booted="true"><div class="v-tabs__bar theme--light"><!---->
                      
                      
                      <div class="v-tabs__wrapper"><div class="v-tabs__container"><div class="v-tabs__slider-wrapper" style="left: 0px; width: 110px;"><div class="v-tabs__slider accent"></div></div><div data-v-4a02086c="" class="v-tabs__div"><a class="v-tabs__item v-tabs__item--active" style="position: static;">
                    <h3>Manajerial</h3>
                </a></div><div data-v-4a02086c="" class="v-tabs__div"><a class="v-tabs__item" style="position: static;">
                    
                </a></div><div data-v-4a02086c="" class="v-tabs__div"><a class="v-tabs__item" style="position: static;">
                   
                </a></div></div></div><!----></div><!----></div></div> <div data-v-4a02086c="" class="flex xs12"><div data-v-c268df26="" data-v-4a02086c=""><div data-v-c268df26="" id="competency-table" class="elevation-1"><div class="v-table__overflow"><table class="v-datatable v-table theme--light" border='1'><thead><tr><th role="columnheader" scope="col" aria-label="No.: Not sorted." aria-sort="none" class="column text-xs-left" width="67px">No.</th><th role="columnheader" scope="col" aria-label="Jenis Kompetensi: Not sorted." aria-sort="none" class="column text-xs-left">Jenis Kompetensi</th><th role="columnheader" scope="col" aria-label="Komponen: Not sorted." aria-sort="none" class="column text-xs-left">Komponen</th><th role="columnheader" scope="col" aria-label="Deskripsi: Not sorted." aria-sort="none" class="column text-xs-left">Deskripsi</th><th role="columnheader" scope="col" aria-label="Indikator: Not sorted." aria-sort="none" class="column text-xs-left">Indikator</th><th role="columnheader" scope="col" aria-label="Tingkat Kompetensi: Not sorted." aria-sort="none" class="column text-xs-left">Tingkat Kompetensi</th></tr><tr class="v-datatable__progress"><th colspan="6" class="column"></th></tr></thead><tbody><tr><td data-v-c268df26="" rowspan="3" style="vertical-align: top;">1.</td> <td data-v-c268df26="" rowspan="9" style="vertical-align: top;">Manajerial</td> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Pengembangan Diri dan Orang Lain</td> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Pengembangan
diri</td> <td data-v-c268df26="">1.1. Mengidentifikasi kebutuhan pengembangan diri dan menyeleksi sumber serta metodologi pembelajaran yang diperlukan;</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1876" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1876" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1876" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1876" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.2. Menunjukkan usaha mandiri untuk mempelajari keterampilan atau kemampuan baru dari berbagai media pembelajaran;</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1887" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1887" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1887" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1887" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.3. Berupaya meningkatkan diri dengan belajar dari orang- orang lain yang berwawasan luas di dalam organisasi.</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1898" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1898" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1898" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1898" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><td data-v-c268df26="" rowspan="3" style="vertical-align: top;">2.</td> <!----> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Mengelola Perubahan</td> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Mengikuti perubahan dengan arahan</td> <td data-v-c268df26="">1.1. Sadar mengenai perubahan yang terjadi di organisasi dan berusaha menyesuaikan diri dengan perubahan tersebut;</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1909" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1909" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1909" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1909" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.2. Mengikuti perubahan secara terbuka sesuai petunjuk/pedoman;</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1920" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1920" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1920" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1920" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.3. Menyesuaikan cara kerja lama dengan menerapkan metode/proses baru dengan bimbingan orang lain.</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1931" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1931" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1931" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1931" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><td data-v-c268df26="" rowspan="3" style="vertical-align: top;">3.</td> <!----> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Pengambilan Keputusan</td> <td data-v-c268df26="" rowspan="3" style="vertical-align: top;">Mengumpulkan informasi untuk bertindak sesuai kewenangan</td> <td data-v-c268df26="">1.1. Mengumpulkan dan mempertimbangkan informasi yang dibutuhkan dalam mencari solusi.</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1942" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1942" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1942" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1942" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.2. Mengenali situasi/pilihan yang tepat untuk bertindak sesuai kewenangan</td> <td data-v-c268df26="" style="vertical-align: middle; width: 155px; padding: 24px;"><div data-v-c268df26="" class="layout row wrap align-center"><div data-v-c268df26="" class="flex"><div data-v-c268df26="" class="v-input score-radio v-input--selection-controls v-input--radio-group v-input--radio-group--row theme--light"><div class="v-input__control"><div class="v-input__slot" style="height: auto;"><div role="radiogroup" class="v-input--radio-group__input"><div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Belum Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1953" value="25"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Belum Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kurang Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1953" value="50"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kurang Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Cukup Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1953" value="79"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Cukup Kompeten</label></div> <div data-v-c268df26="" class="v-radio theme--light"><div class="v-input--selection-controls__input"><input aria-label="Kompeten" aria-checked="false" role="radio" type="radio" name="v-radio-1953" value="100"><div class="v-input--selection-controls__ripple"></div><i aria-hidden="true" class="v-icon material-icons theme--light"></i></div><label aria-hidden="true" class="v-label theme--light" style="left: 0px; right: auto; position: relative;">Kompeten</label></div></div></div><div class="v-messages theme--light"><div class="v-messages__wrapper"></div></div></div></div></div></div></td> <!----></tr><tr><!----> <!----> <!----> <!----> <td data-v-c268df26="">1.3.
 Mempertimbangkan kemungkinan solusi yang dapat diterapkan dalam 
pekerjaan rutin berdasarkan kebijakan dan prosedur yang telah 
ditentukan.</td> 
</tr>
</table>