<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/multipleselect/select2.min.css"/>
<?php //include('tambah.php'); ?>

<table class="table table-bordered" id="example1">
	<thead>
		<tr>
			<th width="5%">No</th>
			<th width="50%">NIP</th>
			<th width="50%">Nama</th>
			<th width="50%">Unit Kerja</th>
			<th width="50%">Jenis Kompetensi</th>
			<th width="50%">Jenis Pelatihan</th>
			<th width="50%">Pengembangan Kompetensi</th>
			<th width="50%">Hasil Kesesuaian</th>
			<th width="50%">Hasil Kemanfaatan</th>
			<th width="50%">Realisasi JP</th>
		</tr>
	</thead>
	<tbody>
		
	</tbody>
</table>






		
		