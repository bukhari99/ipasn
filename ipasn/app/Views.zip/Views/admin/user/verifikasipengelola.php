<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/multipleselect/select2.min.css"/>
<?php //include('tambah.php'); ?>

<table class="table table-bordered" id="example1">
	<thead>
		<tr>
			<th width="5%">No</th>
			<th width="20%">Aksi</th>
			<th width="50%">NIP</th>
			<th width="50%">Nama</th>
			<th width="50%">Jabatan </th>
			<th width="50%">Status</th>
		</tr>
	</thead>
	<tbody>
		
	</tbody>
</table>






		
		