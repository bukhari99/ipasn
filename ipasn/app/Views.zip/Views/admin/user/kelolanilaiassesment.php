<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/multipleselect/select2.min.css"/>
<?php //include('tambah.php'); ?>

<table class="table table-bordered" id="example1">
	<thead>
		<tr>
			<th width="5%">No</th>
			<th width="20%">Aksi</th>
			<th width="50%">NIP</th>
			<th width="50%">Nama</th>
			<th width="50%">Instansi </th>
			<th width="50%">Periode Bangkom</th>
			<th width="50%">Nilai Kinerja</th>
			<th width="50%">Nilai Rata-rata Kompetensi</th>
			<th width="50%">Nilai Manajerial</th>
			<th width="50%">Nilai Sosial</th>
			<th width="50%">Nilai Teknis</th>
		</tr>
	</thead>
	<tbody>
		
	</tbody>
</table>






		
		