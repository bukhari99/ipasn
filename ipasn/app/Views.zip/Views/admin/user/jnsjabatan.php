<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/multipleselect/select2.min.css"/>
<?php //include('tambah.php'); ?>

<table class="table table-bordered" id="example1">
	<thead>
		<tr>
			<th width="5%">No</th>
			
			<th width="30%">Jabatan</th>
			<th width="30%">Jenjang Jabatan</th>
			<th width="50%">Nama Jabatan</th>
		</tr>
	</thead>
	<tbody>
		
		<tr>
			<td>1.</td>
			<td>Jabatan Administrasi</td>
			<td>JA Administrator</td>
			<td>Kepala Bagian Sumber Daya Manusia</td>
		</tr>
		<tr>
			<td>2.</td>
			<td>Jabatan Administrasi</td>
			<td>JA Administrator</td>
			<td>Kepala Bagian Umum</td>
		</tr>
		<tr>
			<td>3.</td>
			<td>Jabatan Administrasi</td>
			<td>JA Administrator</td>
			<td>Kepala Bagian Pengadaan Barang/Jasa dan Barang Milik Negara</td>
		</tr>
	</tbody>
</table>






		
		